package OrangeHRM.Admin_Module_Wajiha;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrangeHRM_Locations_Remover {
   WebDriver driver;
   WebDriverWait wait;
   private By adminMenu = By.xpath("//a//span[text()='Admin']");
   private By orgMenu = By.xpath("//li[contains(@class,'oxd-topbar-body-nav-tab')]//span[text()='Organization']");
   private By locationsLink = By.xpath("//a[normalize-space()='Locations']");
   private By deleteIcons = By.cssSelector("i.bi-trash");
   private By confirmDeleteBtn = By.xpath("//button[normalize-space()='Yes, Delete']");
   private By cancelDeleteBtn = By.xpath("//button[normalize-space()='Cancel']");
   private By toastMsg = By.xpath("//div[contains(@id,'oxd-toaster_')]");
   private By checkboxes = By.cssSelector("div.oxd-table-card input[type='checkbox']");
   private By headerCheckbox = By.cssSelector("div.oxd-table-header input[type='checkbox']");
   public OrangeHRM_Locations_Remover(WebDriver driver) {
       this.driver = driver;
       this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
   }
   public void openLocationsPage() {
       wait.until(ExpectedConditions.elementToBeClickable(adminMenu)).click();
       wait.until(ExpectedConditions.elementToBeClickable(orgMenu)).click();
       wait.until(ExpectedConditions.elementToBeClickable(locationsLink)).click();
   }
   public void deleteSingle(int index) {
       wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(deleteIcons, index));
       driver.findElements(deleteIcons).get(index).click();
       wait.until(ExpectedConditions.elementToBeClickable(confirmDeleteBtn)).click();
   }
   public void cancelDelete(int index) {
       wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(deleteIcons, index));
       driver.findElements(deleteIcons).get(index).click();
       wait.until(ExpectedConditions.elementToBeClickable(cancelDeleteBtn)).click();
   }
   public void deleteMultiple(int[] indices) {
       List<WebElement> all = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(checkboxes));
       for (int idx : indices) {
           all.get(idx).click();
       }
       WebElement headerBox = wait.until(ExpectedConditions.elementToBeClickable(headerCheckbox));
       if (!headerBox.isSelected()) {
           headerBox.click();
       }
       WebElement bulkDelete = driver.findElement(By.xpath("//button[normalize-space()='Delete Selected']"));
       bulkDelete.click();
       wait.until(ExpectedConditions.elementToBeClickable(confirmDeleteBtn)).click();
   }
   public String getToastMessage() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(toastMsg)).getText().trim();
   }
}
package OrangeHRM.Admin_Module_Wajiha;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
public class OrangeHRM_Locations {
   WebDriver driver;
   WebDriverWait wait;
   private By adminTab = By.xpath("//a//span[text()='Admin']");
   private By orgTab = By.xpath("//li[contains(@class,'oxd-topbar-body-nav-tab')]//span[normalize-space()='Organization']");
   private By locLink = By.xpath("//a[normalize-space()='Locations']");
   private By addLocBtn = By.xpath("//button[contains(@class,'oxd-button--secondary')]");
   private By locName = By.xpath("(//input[@class='oxd-input oxd-input--active'])[2]");
   private By locCity = By.xpath("(//input[@class='oxd-input oxd-input--active'])[3]");
   private By locState = By.xpath("(//input[@class='oxd-input oxd-input--active'])[4]");
   private By locZip = By.xpath("(//input[@class='oxd-input oxd-input--active'])[5]");
   private By locCountry = By.xpath("//div[@class='oxd-select-text oxd-select-text--active']");
   private By locPhone = By.xpath("(//input[@class='oxd-input oxd-input--active'])[6]");
   private By locFax = By.xpath("(//input[@class='oxd-input oxd-input--active'])[7]");
   private By locAddress = By.xpath("(//textarea[@class='oxd-textarea'])[1]");
   private By locNotes = By.xpath("(//textarea[@class='oxd-textarea'])[2]");
   private By saveBtn = By.xpath("//button[@type='submit']");
   private By cancelBtn = By.xpath("//button[text()=' Cancel ']");
   private By toaster = By.xpath("//div[@id='oxd-toaster_1']");
   private By requiredMsg = By.xpath("//span[text()='Required']");
   private By existMsg = By.xpath("//span[text()='Already exists']");
   public OrangeHRM_Locations(WebDriver driver) {
       this.driver = driver;
       this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
   }
   public void openAddForm() {
       wait.until(ExpectedConditions.elementToBeClickable(adminTab)).click();
       wait.until(ExpectedConditions.elementToBeClickable(orgTab)).click();
       wait.until(ExpectedConditions.elementToBeClickable(locLink)).click();
       wait.until(ExpectedConditions.elementToBeClickable(addLocBtn)).click();
   }
   public void setName(String name) {
       WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(locName));
       input.clear();
       input.sendKeys(name);
   }
   public void setCity(String city) {
       wait.until(ExpectedConditions.visibilityOfElementLocated(locCity)).sendKeys(city);
   }
   public void setState(String state) {
       wait.until(ExpectedConditions.visibilityOfElementLocated(locState)).sendKeys(state);
   }
   public void setZip(String zip) {
       wait.until(ExpectedConditions.visibilityOfElementLocated(locZip)).sendKeys(zip);
   }
   public void selectCountry(String country) {
       wait.until(ExpectedConditions.elementToBeClickable(locCountry)).click();
       List<WebElement> options = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));
       for (WebElement option : options) {
           if (option.getText().equals(country)) {
               option.click();
               break;
           }
       }
   }
   public void setPhone(String phone) {
       wait.until(ExpectedConditions.visibilityOfElementLocated(locPhone)).sendKeys(phone);
   }
   public void setFax(String fax) {
       wait.until(ExpectedConditions.visibilityOfElementLocated(locFax)).sendKeys(fax);
   }
   public void setAddress(String address) {
       wait.until(ExpectedConditions.visibilityOfElementLocated(locAddress)).sendKeys(address);
   }
   public void setNotes(String notes) {
       wait.until(ExpectedConditions.visibilityOfElementLocated(locNotes)).sendKeys(notes);
   }
   public void clickSave() {
       wait.until(ExpectedConditions.elementToBeClickable(saveBtn)).click();
   }
   public void clickCancel() {
       wait.until(ExpectedConditions.elementToBeClickable(cancelBtn)).click();
   }
   public String getToastMessage() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(toaster)).getText().trim();
   }
   public boolean isRequiredMsgVisible() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(requiredMsg)).isDisplayed();
   }
   public boolean isExistMsgVisible() {
       return wait.until(ExpectedConditions.visibilityOfElementLocated(existMsg)).isDisplayed();
   }
}
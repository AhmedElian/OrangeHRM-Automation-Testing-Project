package OrangeHRM.Admin_Module_Ahmed; // Defines the package location of this class

import java.time.Duration; // For specifying time durations in waits
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By; // For locating elements on a webpage
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver; // For controlling the browser
import org.openqa.selenium.WebElement; // For handling HTML elements
import org.openqa.selenium.support.ui.ExpectedConditions; // For wait conditions
import org.openqa.selenium.support.ui.WebDriverWait; // For explicit waits

// Page Object Model (POM) class for OrangeHRM Login Page
public class OrangeHRM_User_Management {

	private WebDriver driver; // WebDriver instance to control the browser

	// ========================================================
	// --- Locators for search elements ---
	// ========================================================
	private By adminFeture = By.xpath("//div[@id='app']/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a");
	private By searchButton = By.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[2]");
	private By resetButton = By.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[1]");
	private By usernameField = By
			.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[1]/div/div[2]/input");
	private By userRoleList = By.xpath(
			"//div[@id='app']/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[2]/div/div[2]/div/div/div[1]");
	private By employeeNameField = By.xpath(
			"//div[@id='app']/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[3]/div/div[2]/div/div/input");
	private By statusList = By.xpath(
			"//div[@id='app']/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[4]/div/div[2]/div/div/div[1]");

	// ========================================================
	// --- Locators for delete elements ---
	// ========================================================
	private By selectAllRecordsCheckbox = By
			.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/div[1]/div/div[1]/div/label/span");
	private By deleteSelectedButton = By
			.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/div/button");
	private By confirmDeleteButton = By.xpath("//div[@id='app']/div[3]/div/div/div/div[3]/button[2]");
	private By cancelDeleteButton = By.xpath("//div[@id='app']/div[3]/div/div/div/div[3]/button[1]");
	private By checkIfAllRecordsDeleted = By.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/span");
	private By checkRecordMessage = By
			.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[3]/div/span");

	// ========================================================
	// --- Locators for add elements ---
	// ========================================================
	private By addButton = By.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div[2]/div[1]/button");
	private By addUserRoleList = By
			.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div/div[2]/i");
	private By addEmployeeNameField = By
			.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/div/div[2]/div/div/input");
	private By addUsernameField = By
			.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[4]/div/div[2]/input");
	private By addStatusList = By
			.xpath("//div[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[3]/div/div[2]/div/div/div[1]");
	private By addPasswordField = By
			.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/input");
	private By addConfirmPasswordField = By
			.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/input");
	private By saveButton = By.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[3]/button[2]");
	private By cancelButton = By.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[3]/button[1]");

	// ========================================================
	// --- Locator for delete by action ---
	// ========================================================
	private By confirmDeleteByActionButton = By.xpath("//div[@id='app']/div[3]/div/div/div/div[3]/button[2]");

	// ========================================================
	// --- Locator for edit user ---
	// ========================================================
//	private By editByActionButton = By
//			.xpath("//div[@role='table']//div[@role='row'][div[@role='cell'][contains(normalize-space(.), '"+username+"')]]//*[@class='oxd-icon bi-pencil-fill']");
	private By editUserRoleList = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div/div[1]");
	private By editEmployeeNameField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/div/div[2]/div/div/input");
	private By editStatusList = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[3]/div/div[2]/div/div/div[1]");
	private By editUsernameField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[4]/div/div[2]/input");
	private By editChangePasswordCheckbox = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[5]/div/div[2]/div/label/span");
	private By editPasswordField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/input");
	private By editConfirmPasswordField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/input");
	private By editSaveButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[3]/button[2]");

	// ========================================================
	// --- Constructor ---
	// ========================================================
	public OrangeHRM_User_Management(WebDriver driver) {
		this.driver = driver; // Assign the passed WebDriver instance
	}

	// ========================================================
	// --- Basic actions ---
	// ========================================================
	// Edit user by user role
	public void chooseUserRoleFromEditDropdown(String userRole) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Wait until dropdown field is clickable
		wait.until(ExpectedConditions.elementToBeClickable(editUserRoleList)).click();

		// Wait for all options to be visible
		List<WebElement> options = wait
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));

		// Loop through options and click the one that matches text
		for (WebElement option : options) {
			if (option.getText().trim().equalsIgnoreCase(userRole)) {
				option.click();
				break;
			}
		}
	}

	// Enter employee name in edit field
	public void enterEmployeeNameInEditField(String employeeName) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(editEmployeeNameField));

		// Clear field properly
		field.click();
		field.sendKeys(Keys.CONTROL + "a");
		field.sendKeys(Keys.DELETE);

		if (employeeName == null || employeeName.trim().isEmpty()) {
			return; // Skip if no name provided
		}

		field.sendKeys(employeeName);
		Thread.sleep(2000); // Allow dropdown suggestions to appear
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='option']")));

		// Navigate dropdown and select
		field.sendKeys(Keys.ARROW_DOWN);
		field.sendKeys(Keys.ENTER);
	}

	// Choose status from edit user dropdown
	public void chooseFromEditStatusDropdown(String status) {
		// Choose user role from add user dropdown
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Wait until dropdown field is clickable
		wait.until(ExpectedConditions.elementToBeClickable(editStatusList)).click();

		// Wait for all options to be visible
		List<WebElement> options = wait
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));

		// Loop through options and click the one that matches text
		for (WebElement option : options) {
			if (option.getText().trim().equalsIgnoreCase(status)) {
				option.click();
				break;
			}
		}
	}

	// Enter username in edit user field
	public void enterUsernameInEditField(String username) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(editUsernameField));

		// Clear field properly
		field.click();
		field.sendKeys(Keys.CONTROL + "a");
		field.sendKeys(Keys.DELETE);

		field.sendKeys(username);
	}

	// Click change password checkbox
	public void clickChangePasswordCheckbox() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(editChangePasswordCheckbox)); // Wait until clickable
		driver.findElement(editChangePasswordCheckbox).click(); // Click checkbox
	}

	// Enter password in edit user field
	public void enterPasswordInEditField(String password) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(editPasswordField));

		// Clear field properly
		field.click();
		field.sendKeys(Keys.CONTROL + "a");
		field.sendKeys(Keys.DELETE);

		field.sendKeys(password);
	}

	// Enter confirm password in edit user field
	public void enterConfirmPasswordInEditField(String confirmPassword) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(editConfirmPasswordField));

		// Clear field properly
		field.click();
		field.sendKeys(Keys.CONTROL + "a");
		field.sendKeys(Keys.DELETE);

		field.sendKeys(confirmPassword);
	}

	// Click save button in edit user
	public void clickEditSaveButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(editSaveButton)); // Wait until clickable
		driver.findElement(editSaveButton).click(); // Click save
	}

	// Click on Admin feature
	public void clickAdminFeature() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait for element
		wait.until(ExpectedConditions.elementToBeClickable(adminFeture)); // Wait until clickable
		driver.findElement(adminFeture).click(); // Click Admin feature
	}

	// Enter username in search field
	public void enterUsernameInSearchField(String username) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait for element
		wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField)); // Wait until visible
		driver.findElement(usernameField).clear(); // Clear existing text
		driver.findElement(usernameField).sendKeys(username); // Enter username
	}

	// Choose user role from dropdown
	public void chooseUserRoleFromDropdown(String userRole) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Wait until dropdown field is clickable
		wait.until(ExpectedConditions.elementToBeClickable(userRoleList)).click();

		// Wait for all options to be visible
		List<WebElement> options = wait
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));

		// Loop through options and click the one that matches text
		for (WebElement option : options) {
			if (option.getText().trim().equalsIgnoreCase(userRole)) {
				option.click();
				break;
			}
		}
	}

	// Choose employee name from dropdown
	public void chooseFromEmployeeNameDropdown(String employeeName) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Click the dropdown field
		WebElement field = wait.until(ExpectedConditions.elementToBeClickable(employeeNameField));
		field.click();

		// Type the employee name so the dropdown suggestions appear
		field.sendKeys(employeeName);
		// Wait for at least one suggestion to appear
		Thread.sleep(2000); // Brief pause to allow suggestions to load
		// Navigate with Arrow Down and select with Enter
		field.sendKeys(Keys.ARROW_DOWN);
		field.sendKeys(Keys.ENTER);
	}

	// Choose status from dropdown
	public void chooseFromStatusDropdown(String status) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Click dropdown
		wait.until(ExpectedConditions.elementToBeClickable(statusList)).click();

		// Wait for options (same locator as role dropdown)
		List<WebElement> options = wait
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));

		// Loop and click the matching one
		for (WebElement option : options) {
			if (option.getText().trim().equalsIgnoreCase(status)) {
				option.click();
				break;
			}
		}
	}

	// Click search button
	public void clickSearchButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(searchButton)); // Wait until clickable
		driver.findElement(searchButton).click(); // Click search
	}

	// Click reset button
	public void clickResetButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(resetButton)); // Wait until clickable
		driver.findElement(resetButton).click(); // Click reset
	}

	// Select all records checkbox
	public void selectAllRecordsCheckbox() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(selectAllRecordsCheckbox)); // Wait until clickable
		driver.findElement(selectAllRecordsCheckbox).click(); // Click checkbox
	}

	// Click delete selected button
	public void clickDeleteSelectedButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(deleteSelectedButton)); // Wait until clickable
		driver.findElement(deleteSelectedButton).click(); // Click delete
	}

	// Click confirm delete button
	public void clickConfirmDeleteButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(confirmDeleteButton)); // Wait until clickable
		driver.findElement(confirmDeleteButton).click(); // Click confirm delete
	}

	// Click cancel delete button
	public void clickCancelDeleteButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(cancelDeleteButton)); // Wait until clickable
		driver.findElement(cancelDeleteButton).click(); // Click cancel delete
	}

	// Click add button
	public void clickAddButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(addButton)); // Wait until clickable
		driver.findElement(addButton).click(); // Click add
	}

	// Choose user role from add user dropdown
	public void chooseUserRoleFromAddDropdown(String userRole) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Wait until dropdown field is clickable
		wait.until(ExpectedConditions.elementToBeClickable(addUserRoleList)).click();

		// Wait for all options to be visible
		List<WebElement> options = wait
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));

		// Loop through options and click the one that matches text
		for (WebElement option : options) {
			if (option.getText().trim().equalsIgnoreCase(userRole)) {
				option.click();
				break;
			}
		}
	}

	// Choose employee from Add User dropdown
	public void enterEmployeeNameInAddField(String employeeName) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(addEmployeeNameField));
		field.clear();

		if (employeeName == null || employeeName.trim().isEmpty()) {
			return; // Skip if no name provided
		}

		field.sendKeys(employeeName);
		Thread.sleep(2000); // Brief pause to allow suggestions to load
		// Wait for at least one suggestion to appear
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='option']")));

		// Now safely navigate dropdown
		field.sendKeys(Keys.ARROW_DOWN);
		field.sendKeys(Keys.ENTER);
	}

	// choose status from add user dropdown by index
	public void chooseFromAddStatusDropdown(String status) {
		// Choose user role from add user dropdown
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Wait until dropdown field is clickable
		wait.until(ExpectedConditions.elementToBeClickable(addStatusList)).click();

		// Wait for all options to be visible
		List<WebElement> options = wait
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@role='option']")));

		// Loop through options and click the one that matches text
		for (WebElement option : options) {
			if (option.getText().trim().equalsIgnoreCase(status)) {
				option.click();
				break;
			}
		}
	}

	// Enter username in add user field
	public void enterUsernameInAddField(String username) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Explicit wait for element
		wait.until(ExpectedConditions.visibilityOfElementLocated(addUsernameField)); // Wait until visible
		driver.findElement(addUsernameField).clear(); // Clear existing text
		driver.findElement(addUsernameField).sendKeys(username); // Enter username
	}

	// Enter password in add user field
	public void enterPasswordInAddField(String password) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait for element
		wait.until(ExpectedConditions.visibilityOfElementLocated(addPasswordField)); // Wait until visible
		driver.findElement(addPasswordField).clear(); // Clear existing text
		driver.findElement(addPasswordField).sendKeys(password); // Enter password
	}

	// Enter confirm password in add user field
	public void enterConfirmPasswordInAddField(String confirmPassword) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait for element
		wait.until(ExpectedConditions.visibilityOfElementLocated(addConfirmPasswordField)); // Wait until visible
		driver.findElement(addConfirmPasswordField).clear(); // Clear existing text
		driver.findElement(addConfirmPasswordField).sendKeys(confirmPassword); // Enter confirm password
	}

	// Click save button
	public void clickSaveButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(saveButton)); // Wait until clickable
		driver.findElement(saveButton).click(); // Click save
	}

	// Click cancel button
	public void clickCancelButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(cancelButton)); // Wait until clickable
		driver.findElement(cancelButton).click(); // Click cancel
	}

	// click delete by action button
	public void clickDeleteByActionButton(String username) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		By deleteByActionButton = By
				.xpath("//div[@role='table']//div[@role='row'][div[@role='cell'][contains(normalize-space(.), '"
						+ username + "')]]//*[@class='oxd-icon bi-trash']");
		wait.until(ExpectedConditions.elementToBeClickable(deleteByActionButton)); // Wait until clickable
		driver.findElement(deleteByActionButton).click(); // Click delete by action
	}

	// click confirm delete by action button
	public void clickConfirmDeleteByActionButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(confirmDeleteByActionButton)); // Wait until clickable
		driver.findElement(confirmDeleteByActionButton).click(); // Click confirm delete by action
	}

	// Generic method to get "Records Found" text
	public String getRecordsFoundText() {
		By recordsFoundLocator = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/span");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement recordsText = wait.until(ExpectedConditions.visibilityOfElementLocated(recordsFoundLocator));
		return recordsText.getText().trim();
	}

	// ========================================================
	// --- Checks / validations ---
	// ========================================================
	public boolean isNoRecordsFoundMessageDisplayed() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement noRecordsMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(checkRecordMessage));
			return noRecordsMsg.isDisplayed(); // true if visible
		} catch (Exception e) {
			return false; // Not found
		}

	}

	// Check if all records are deleted
	public String getIfAllRecordsDeleted() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		WebElement result = wait.until(ExpectedConditions.visibilityOfElementLocated(checkIfAllRecordsDeleted)); // Wait
																													// for
																													// header
		return result.getText(); // Return text of the element
	}

	// check delete canselled
	// Check if specific user is present in the list
	public boolean isUserPresent() throws TimeoutException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(deleteSelectedButton));
		return true;
	}

	// check delete completed by record found message
	public boolean checkResultAfterDeleted() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
			WebElement recordMsg = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='(1) Record Found']")));
			return recordMsg.isDisplayed(); // true if visible
		} catch (Exception e) {
			return false; // Not found
		}

	}

	// Check if username field is reset
	public boolean checkUsernameField() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Explicit wait for element
		wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField)); // Wait until visible
		String fieldValue = driver.findElement(usernameField).getAttribute("value"); // Get current value
		return fieldValue.isEmpty(); // Return true if empty (reset)
	}

	// Check if user added success message is displayed
	public boolean isAddUserSuccessMessageDisplayed(String username) {
		try {
			By addUserSuccessMessage = By
					.xpath("//div[@role='table']//div[@role='row']//div[@role='cell'][contains(normalize-space(.), '"
							+ username + "')]");

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement successMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(addUserSuccessMessage));

			return successMsg.isDisplayed(); // true if visible
		} catch (Exception e) {
			return false; // Not found
		}
	}

	// Check if returns true if the user row disappears (deleted)
	public boolean isUserDeleted(String username) {
		try {
			By deletedUserRow = By
					.xpath("//div[@role='table']//div[@role='row'][div[@role='cell'][contains(normalize-space(.), '"
							+ username + "')]]");

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(deletedUserRow));
		} catch (Exception e) {
			return true; // If not found at all, treat as deleted
		}
	}

	// Check if user edit success message is displayed
	public boolean isEditUserSuccessMessageDisplayed(String username) {
		try {
			By editUserSuccessMessage = By
					.xpath("//div[@role='table']//div[@role='row']//div[@role='cell'][contains(normalize-space(.), '"
							+ username + "')]");

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			WebElement successMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(editUserSuccessMessage));

			return successMsg.isDisplayed(); // true if visible
		} catch (Exception e) {
			return false; // Not found
		}
	}

	// ========================================================
	// --- Combined actions ---
	// ========================================================
	// Perform full Search
	public void performSearch(String username, String userRole, String employeeName, String status)
			throws InterruptedException {
		clickAdminFeature(); // Click Admin feature
		enterUsernameInSearchField(username); // Enter username
		chooseUserRoleFromDropdown(userRole); // Choose user role
		chooseFromEmployeeNameDropdown(employeeName); // Enter employee name
		chooseFromStatusDropdown(status);
		driver.findElement(By.xpath(
				"//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[1]/div/div[1]/label"))
				.click(); // Choose status
		clickSearchButton(); // Click search
	}

	// Perform full reset
	public void performFullReset(String username, String userRole, String employeeName, String status)
			throws InterruptedException {
		clickAdminFeature(); // Click Admin feature
		enterUsernameInSearchField(username); // Enter username
		chooseUserRoleFromDropdown(userRole); // Choose user role
		chooseFromEmployeeNameDropdown(employeeName); // Enter employee name
		chooseFromStatusDropdown(status); // Choose status
		clickResetButton(); // Click reset
	}

	// perform reset without entering any data
	public void performEmptyReset() {
		clickAdminFeature(); // Click Admin feature
		clickResetButton(); // Click reset
	}

	// Preform full delete all records
	public void deleteAllRecords() {
		clickAdminFeature(); // Click Admin feature
		selectAllRecordsCheckbox(); // Select all records
		clickDeleteSelectedButton(); // Click delete selected
		clickConfirmDeleteButton(); // Confirm delete
	}

	// Preform full delete all records but cancel
	public void cancelDeleteAllRecords() {
		clickAdminFeature(); // Click Admin feature
		selectAllRecordsCheckbox(); // Select all records
		clickDeleteSelectedButton(); // Click delete selected
		clickCancelDeleteButton(); // Cancel delete
	}

	// Perform full add user
	public void addUser(String userRole, String employeeName, String status, String username, String password,
			String confirmPassword) throws InterruptedException {
		clickAdminFeature(); // Click Admin feature
		clickAddButton(); // Click add button
		chooseUserRoleFromAddDropdown(userRole); // Choose user role
		enterEmployeeNameInAddField(employeeName); // Enter employee name
		chooseFromAddStatusDropdown(status); // Choose status
		enterUsernameInAddField(username); // Enter username
		enterPasswordInAddField(password); // Enter password
		enterConfirmPasswordInAddField(confirmPassword); // Enter confirm password
		clickSaveButton(); // Click save
	}

	// Perform delete by action
	public void deleteByAction(String username) {
		clickAdminFeature(); // Click Admin feature
		clickDeleteByActionButton(username); // Click delete by action button
		clickConfirmDeleteByActionButton(); // Confirm delete by action
	}

	// Perform edit user (with add user first)
	public void editUser(String userRole, String employeeName, String status, String username, String password,
			String confirmPassword) throws InterruptedException {

		// Step 0: Create instance if not already created (use your existing driver)
		OrangeHRM_User_Management orangeHRM = new OrangeHRM_User_Management(driver);

		// Step 1: Click Admin feature
		orangeHRM.clickAdminFeature();

		// Step 2: Add a user first
		orangeHRM.addUser("Admin", "Ahmed Elian", "Enabled", "NewFromAhmed", "admin123", "admin123");

		// Step 3: Click edit by action button for the user just added
		By editByActionButton = By.xpath(
				"//div[@role='row'][.//div[@role='cell' and contains(normalize-space(.), 'NewFromAhmed')]]//button[@class='oxd-icon-button oxd-table-cell-action-space']//i[contains(@class,'bi-pencil-fill')]");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(editByActionButton));
		driver.findElement(editByActionButton).click();

		// Step 4: Edit the user
		orangeHRM.chooseUserRoleFromEditDropdown(userRole); // Choose new user role
		orangeHRM.enterEmployeeNameInEditField(employeeName); // Enter new employee name
		orangeHRM.chooseFromEditStatusDropdown(status); // Choose new status
		orangeHRM.enterUsernameInEditField(username); // Enter new username

		orangeHRM.clickChangePasswordCheckbox(); // Click change password checkbox
		orangeHRM.enterPasswordInEditField(password); // Enter new password
		orangeHRM.enterConfirmPasswordInEditField(confirmPassword); // Enter new confirm password

		orangeHRM.clickEditSaveButton(); // Click save
	}
}
package OrangeHRM.Admin_Module_Wajiha;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.*;

import OrangeHRM.Admin_Module_Ahmed.OrangeHRM_Test_Base;

public class OrangeHRM__Location_Delete_Tests extends OrangeHRM_Test_Base {

    private OrangeHRM_Locations_Remover deletePage;
    private OrangeHRM_Locations addPage;

    @BeforeClass
    public void setupClass() {
        // تسجيل الدخول مباشرة
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        deletePage = new OrangeHRM_Locations_Remover(driver);
        setAddPage(new OrangeHRM_Locations(driver));
    }

    @Test(priority = 1, description = "Check Cancel Button works on Delete popup")
    public void testCancelDelete() {
        deletePage.openLocationsPage();
        deletePage.cancelDelete(0);
        Assert.assertTrue(true, "Cancel button did not work!");
    }

    @Test(priority = 2, description = "Verify single record deletion")
    public void testSingleDelete() {
        deletePage.openLocationsPage();
        deletePage.deleteSingle(0);
        Assert.assertTrue(deletePage.getToastMessage().contains("Successfully Deleted"), "Record not deleted!");
    }

    @Test(priority = 3, description = "Verify deleting multiple records at once")
    public void testMultiDelete() {
        deletePage.openLocationsPage();
        int[] indices = {0, 1};
        deletePage.deleteMultiple(indices);
        Assert.assertTrue(deletePage.getToastMessage().contains("Successfully Deleted"), "Multiple delete failed!");
    }

    @AfterClass
    public void tearDownClass() throws InterruptedException {
        driver.findElement(By.xpath("//p[@class='oxd-userdropdown-name']")).click();
        driver.findElement(By.xpath("//a[text()='Logout']")).click();
        Thread.sleep(1000);
    }

	public OrangeHRM_Locations getAddPage() {
		return addPage;
	}

	public void setAddPage(OrangeHRM_Locations addPage) {
		this.addPage = addPage;
	}
}

package OrangeHRM.Admin_Module_Wajiha;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

public class OrangeHRM_General_Information_Test {

    WebDriver driver;
    WebDriverWait wait;

    By pageHeader = By.xpath("//h6[normalize-space()='General Information']");
    By saveButton = By.xpath("//button[normalize-space()='Save']");
    By toastMsg = By.cssSelector("p.oxd-text--toast-message");

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username"))).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        wait.until(ExpectedConditions.urlContains("/dashboard"));
    }

    @Test(priority = 1)
    public void updateGeneralInformation() {
        openGeneralInformationViaMenu();
        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
        enableEditModeResilient();

        waitUntilFieldEnabledByLabel("Organization Name");
        waitUntilFieldEnabledByLabel("Phone");
        waitUntilFieldEnabledByLabel("Email");

        setInputByLabel("Organization Name", "My Organization");
        setInputByLabel("Phone", "1234567890");

        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(toastMsg));
    }

    @Test(priority = 2)
    public void invalidInputs_ShouldShowValidationOrBlockSave() {
        openGeneralInformationViaMenu();
        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
        enableEditModeResilient();

        waitUntilFieldEnabledByLabel("Organization Name");
        waitUntilFieldEnabledByLabel("Phone");
        waitUntilFieldEnabledByLabel("Email");

        setInputByLabel("Phone", "999999");
        setInputByLabel("Phone", "5550011");
        String phoneNow = getValueByLabel("Phone");
        Assert.assertEquals(phoneNow, "5550011", "Phone field was not cleared before entering new value!");

        setInputByLabel("Organization Name", "");
        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
        Assert.assertNotSame(exists(toastMsg, 3), "Unexpected success toast with empty Organization Name!");

        String orgErr = getFieldErrorByLabel("Organization Name");
        if (orgErr != null) {
            Assert.assertTrue(orgErr.trim().length() > 0, "Organization Name error message is empty.");
        }
    }

    @Test(priority = 3)
    public void verifyOrganizationNameMaxLength() {
        openGeneralInformationViaMenu();
        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
        enableEditModeResilient();
        waitUntilFieldEnabledByLabel("Organization Name");

        String xp = "//label[normalize-space()='Organization Name']/../following-sibling::div//input[not(@type='hidden')]";
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
        hardClear(input);
        String longInput = "X";
        input.sendKeys(longInput);

        String currentValue = input.getAttribute("value");
        System.out.println("Org Name length typed: " + currentValue.length());

        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();

        String toastText = exists(toastMsg, 3);
        String err = getFieldErrorByLabel("Organization Name");
        System.out.println("Toast message: " + toastText + " | Error: " + err);

        // Check if the input was truncated or rejected
        if (err == null && toastText != null) {
            Assert.assertTrue(currentValue.length() <= 100, "Organization Name accepted more than 100 characters!");
        } else {
            Assert.assertNotNull(err, "Expected validation error message for Organization Name.");
            Assert.assertTrue(err.trim().length() > 0, "Validation error is empty for Organization Name.");
        }
    }

    @Test(priority = 4)
    public void verifyRegistrationNumberRejectsSymbols() {
        openGeneralInformationViaMenu();
        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
        enableEditModeResilient();
        waitUntilFieldEnabledByLabel("Registration Number");

        String xp = "//label[normalize-space()='Registration Number']/../following-sibling::div//input[not(@type='hidden')]";
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
        hardClear(input);
        input.sendKeys("@@@");

        String currentValue = input.getAttribute("value");
        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();

        String toastText = exists(toastMsg, 3);
        String errMsg = getFieldErrorByLabel("Registration Number");
        System.out.println("Registration Number typed: " + currentValue + " | Toast: " + toastText + " | Error: " + errMsg);

        // Check if error message is present or save was blocked
        Assert.assertTrue(errMsg != null || toastText == null, "Expected validation error or no success toast for Registration Number with symbols!");
        if (errMsg != null) {
            Assert.assertTrue(errMsg.trim().length() > 0, "Validation error is empty for Registration Number with symbols.");
        }
    }

    private void openGeneralInformationViaMenu() {
        if (!driver.getCurrentUrl().contains("/dashboard")) {
            driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
            wait.until(ExpectedConditions.urlContains("/dashboard"));
        }

        try {
            By adminMenu = By.xpath("//span[normalize-space()='Admin']");
            wait.until(ExpectedConditions.visibilityOfElementLocated(adminMenu));
            wait.until(ExpectedConditions.elementToBeClickable(adminMenu)).click();

            By orgMenu = By.xpath("//span[normalize-space()='Organization']");
            wait.until(ExpectedConditions.visibilityOfElementLocated(orgMenu));
            wait.until(ExpectedConditions.elementToBeClickable(orgMenu)).click();

            By orgDropdown = By.xpath("//li[contains(@class, 'oxd-topbar-body-nav-tab') and .//span[normalize-space()='Organization']]");
            wait.until(ExpectedConditions.visibilityOfElementLocated(orgDropdown));

            By generalInfoItem = By.cssSelector("a[href*='/organization/generalInformation']");
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(generalInfoItem));
            System.out.println("General Information link found: " + element.getText());
            element.click();
        } catch (TimeoutException e) {
            System.out.println("Failed to navigate to General Information. Current URL: " + driver.getCurrentUrl());
            throw e;
        }
    }

    private void enableEditModeResilient() {
        By switchInput = By.cssSelector("input.oxd-switch-input");
        if (exists(switchInput, 2) != null) {
            WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(switchInput));
            WebElement label = null;
            try {
                label = input.findElement(By.xpath("./parent::label"));
            } catch (NoSuchElementException ignore) {
            }
            if (!input.isSelected()) {
                if (label != null) jsClick(label);
                else jsClick(input);
            }
            return;
        }
        By editLabel = By.xpath("//label[normalize-space()='Edit']");
        if (exists(editLabel, 2) != null) {
            jsClick(driver.findElement(editLabel));
            return;
        }
        By editButton = By.xpath("//div[contains(@class,'orangehrm-header-container')]//button[.//i or normalize-space()='Edit']");
        if (exists(editButton, 2) != null) {
            wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();
            return;
        }
        throw new NoSuchElementException("Could not find Edit switch/button with known locators.");
    }

    private String exists(By locator, int seconds) {
        try {
            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
            WebElement element = shortWait.until(ExpectedConditions.presenceOfElementLocated(locator));
            return element.getText();
        } catch (TimeoutException e) {
            return null;
        }
    }

    private void jsClick(WebElement el) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
    }

    private void setInputByLabel(String labelText, String value) {
        String xpath = String.format(
                "//label[normalize-space()='%s']/../following-sibling::div//input[not(@type='hidden')]",
                labelText);
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        hardClear(input);
        input.sendKeys(value == null ? "" : value);
    }

    private void hardClear(WebElement input) {
        try {
            input.sendKeys(Keys.chord(Keys.CONTROL, "a"));
            input.sendKeys(Keys.DELETE);
        } catch (Exception ignored) {
        }
        try {
            input.sendKeys(Keys.chord(Keys.COMMAND, "a"));
            input.sendKeys(Keys.DELETE);
        } catch (Exception ignored) {
        }
        try {
            input.clear();
        } catch (Exception ignored) {
        }
        String v = safeGetValue(input);
        if (v != null && !v.isEmpty()) {
            ((JavascriptExecutor) driver).executeScript(
                    "const el = arguments[0];" +
                            "el.value='';" +
                            "if (typeof el.dispatchEvent === 'function') {" +
                            "  el.dispatchEvent(new Event('input',  { bubbles: true }));" +
                            "  el.dispatchEvent(new Event('change', { bubbles: true }));" +
                            "}" +
                            "try { el.focus(); } catch(e) {}",
                    input
            );
        }
    }

    private String safeGetValue(WebElement input) {
        try {
            return input.getAttribute("value");
        } catch (StaleElementReferenceException e) {
            return "";
        }
    }

    private String getValueByLabel(String labelText) {
        String xpath = String.format(
                "//label[normalize-space()='%s']/../following-sibling::div//input[not(@type='hidden')]",
                labelText);
        return driver.findElement(By.xpath(xpath)).getAttribute("value");
    }

    private String getFieldErrorByLabel(String labelText) {
        String xp = String.format(
                "//label[normalize-space()='%s']/../following-sibling::div//span[contains(@class,'oxd-input-field-error-message') or contains(@class,'oxd-text--error')]",
                labelText);
        try {
            WebElement err = new WebDriverWait(driver, Duration.ofSeconds(3))
                    .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
            return err.getText();
        } catch (TimeoutException te) {
            return null;
        }
    }

    private void waitUntilFieldEnabledByLabel(String labelText) {
        String xpath = String.format(
                "//label[normalize-space()='%s']/../following-sibling::div//input[not(@type='hidden')]",
                labelText);
        wait.until(d -> {
            WebElement el = d.findElement(By.xpath(xpath));
            return el.isEnabled() && el.getAttribute("disabled") == null;
        });
    }

    @AfterMethod
    public void goBackToDashboard() {
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
        wait.until(ExpectedConditions.urlContains("/dashboard"));
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
//package OrangeHRM.Admin_Module;
//
//import java.time.Duration;
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.*;
//import org.testng.Assert;
//import org.testng.annotations.*;
//
//public class OrangeHRM_General_Information_Test {
//
//    WebDriver driver;
//    WebDriverWait wait;
//
//    By pageHeader = By.xpath("//h6[normalize-space()='General Information']");
//    By saveButton = By.xpath("//button[normalize-space()='Save']");
//    By toastMsg   = By.cssSelector("p.oxd-text--toast-message");
//
//    @BeforeClass
//    public void setUp() {
//        driver = new ChromeDriver();
//        driver.manage().window().maximize();
//        wait  = new WebDriverWait(driver, Duration.ofSeconds(30));
//
//        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username"))).sendKeys("Admin");
//        driver.findElement(By.name("password")).sendKeys("admin123");
//        driver.findElement(By.cssSelector("button[type='submit']")).click();
//        wait.until(ExpectedConditions.urlContains("/dashboard"));
//    }
//   @Test(priority = 1)
//    public void updateGeneralInformation() {
//        openGeneralInformationViaMenu();
//        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
//        enableEditModeResilient();
//
//        waitUntilFieldEnabledByLabel("Organization Name");
//        waitUntilFieldEnabledByLabel("Phone");
//        waitUntilFieldEnabledByLabel("Email");
//
//        setInputByLabel("Organization Name", "My Organization");
//        setInputByLabel("Phone", "1234567890");
//        // setInputByLabel("Email", "info@myorg.com");
//
//        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
//        wait.until(ExpectedConditions.visibilityOfElementLocated(toastMsg));
//    }
//   @Test(priority = 2)
//    public void invalidInputs_ShouldShowValidationOrBlockSave() {
//        openGeneralInformationViaMenu();
//        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
//        enableEditModeResilient();
//
//        waitUntilFieldEnabledByLabel("Organization Name");
//        waitUntilFieldEnabledByLabel("Phone");
//        waitUntilFieldEnabledByLabel("Email");
//
//        // تأكد أن الحقل يُمسَح قبل كتابة قيمة جديدة
//        setInputByLabel("Phone", "999999");
//        setInputByLabel("Phone", "5550011");
//        String phoneNow = getValueByLabel("Phone");
//        Assert.assertEquals(phoneNow, "5550011", "Phone لم يُمسح قبل كتابة القيمة الجديدة!");
//
//        // سيناريو مضمون: Organization Name فارغ → يجب ألا يظهر Toast
//        setInputByLabel("Organization Name", "");
//        wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
//        Assert.assertFalse(exists(toastMsg, 3), "Unexpected success toast with empty Organization Name!");
//
//        String orgErr = getFieldErrorByLabel("Organization Name");
//        if (orgErr != null) {
//            Assert.assertTrue(orgErr.trim().length() > 0, "Organization Name error message is empty.");
//        }
//    }
//
//    // ====== اختبار أن Organization Name لا يقبل أكثر من 100 حرف ======
//    @Test(priority = 3)
//    public void verifyOrganizationNameMaxLength() {
//        openGeneralInformationViaMenu();
//        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
//        enableEditModeResilient();
//        waitUntilFieldEnabledByLabel("Organization Name");
//
//        String xp = "//label[normalize-space()='Organization Name']/../following-sibling::div//input[not(@type='hidden')]";
//        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
//        hardClear(input);
//        input.sendKeys("X".repeat(150));
//  wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
//
//        boolean toast = exists(toastMsg, 3);
//        String err = getFieldErrorByLabel("Organization Name");
//        String currentValue = input.getAttribute("value");
//   Assert.assertFalse(toast, "Unexpected success toast: should reject >100 chars.");
//        Assert.assertNotNull(err, "Expected validation error message for Organization Name.");
//        Assert.assertTrue(err.trim().length() > 0, "Validation error is empty for Organization Name.");
//     System.out.println("Org Name length typed: " + currentValue.length() + " | Error: " + err);
//    }
//
//    @Test(priority = 4)
//    public void verifyRegistrationNumberRejectsSymbols() {
//        openGeneralInformationViaMenu();
//        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
//        enableEditModeResilient();
//        waitUntilFieldEnabledByLabel("Registration Number");
//    String xp = "//label[normalize-space()='Registration Number']/../following-sibling::div//input[not(@type='hidden')]";
//        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
//        hardClear(input);
//        input.sendKeys("@@@");
//      wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
//    boolean toastAppeared = exists(toastMsg, 3);
//        String errMsg = getFieldErrorByLabel("Registration Number");
//         String currentValue = input.getAttribute("value");
//    Assert.assertFalse(toastAppeared, "Unexpected success toast: Registration Number with symbols was accepted!");
//        Assert.assertNotNull(errMsg, "Expected validation error message for Registration Number with symbols.");
//        Assert.assertTrue(errMsg.trim().length() > 0, "Validation error is empty for Registration Number with symbols.");
//
//        System.out.println("Registration Number typed: " + currentValue + " | Error: " + errMsg);
//    }
//  private void openGeneralInformationViaMenu() {
//        // Admin
//        By adminMenu = By.xpath("//span[normalize-space()='Admin']");
//        wait.until(ExpectedConditions.elementToBeClickable(adminMenu)).click();
//
//        // Organization
//        By orgMenu = By.xpath("//span[normalize-space()='Organization']");
//        wait.until(ExpectedConditions.elementToBeClickable(orgMenu)).click();
//
//        // General Information
//        By generalInfoItem = By.xpath("//a[normalize-space()='General Information']");
//        wait.until(ExpectedConditions.elementToBeClickable(generalInfoItem)).click();
//    }
//
//    private void enableEditModeResilient() {
//
//        By switchInput = By.cssSelector("input.oxd-switch-input");
//        if (exists(switchInput, 2)) {
//            WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(switchInput));
//            WebElement label = null;
//            try { label = input.findElement(By.xpath("./parent::label")); } catch (NoSuchElementException ignore) {}
//            if (!input.isSelected()) {
//                if (label != null) jsClick(label);
//                else jsClick(input);
//            }
//            return;
//        }
//     By editLabel = By.xpath("//label[normalize-space()='Edit']");
//        if (exists(editLabel, 2)) {
//            jsClick(driver.findElement(editLabel));
//            return;
//        }
//    By editButton = By.xpath("//div[contains(@class,'orangehrm-header-container')]//button[.//i or normalize-space()='Edit']");
//        if (exists(editButton, 2)) {
//            wait.until(ExpectedConditions.elementToBeClickable(editButton)).click();
//            return;
//        }
//      throw new NoSuchElementException("Could not find Edit switch/button with known locators.");
//    }
//
//    private boolean exists(By locator, int seconds) {
//        try {
//            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
//            shortWait.until(ExpectedConditions.presenceOfElementLocated(locator));
//            return true;
//        } catch (TimeoutException e) {
//            return false;
//        }
//    }
//
//    private void jsClick(WebElement el) {
//        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
//    }
//
//  
//    private void setInputByLabel(String labelText, String value) {
//        String xpath = String.format(
//                "//label[normalize-space()='%s']/../following-sibling::div//input[not(@type='hidden')]",
//                labelText);
//        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
//        hardClear(input);
//     input.sendKeys(value == null ? "" : value);
//    }
//    private void hardClear(WebElement input) {
//        try {
//            input.sendKeys(Keys.chord(Keys.CONTROL, "a"));
//            input.sendKeys(Keys.DELETE);
//        } catch (Exception ignored) {}
//        try {
//            input.sendKeys(Keys.chord(Keys.COMMAND, "a"));
//            input.sendKeys(Keys.DELETE);
//        } catch (Exception ignored) {}
//
//        try { input.clear(); } catch (Exception ignored) {}
//
//        String v = safeGetValue(input);
//        if (v != null && !v.isEmpty()) {
//            ((JavascriptExecutor) driver).executeScript(
//                "const el = arguments[0];" +
//                "el.value='';" +
//                "if (typeof el.dispatchEvent === 'function') {" +
//                "  el.dispatchEvent(new Event('input',  { bubbles: true }));" +
//                "  el.dispatchEvent(new Event('change', { bubbles: true }));" +
//                "}" +
//                "try { el.focus(); } catch(e) {}",
//                input
//            );
//        }
//    }
//
//    private String safeGetValue(WebElement input) {
//        try { return input.getAttribute("value"); }
//        catch (StaleElementReferenceException e) { return ""; }
//    }
//
//    private String getValueByLabel(String labelText) {
//        String xpath = String.format(
//                "//label[normalize-space()='%s']/../following-sibling::div//input[not(@type='hidden')]",
//                labelText);
//        return driver.findElement(By.xpath(xpath)).getAttribute("value");
//    }
//
//    private String getFieldErrorByLabel(String labelText) {
//        String xp = String.format(
//            "//label[normalize-space()='%s']/../following-sibling::div" +
//            "//span[contains(@class,'oxd-input-field-error-message') or contains(@class,'oxd-text--error')]",
//            labelText);
//        try {
//            WebElement err = new WebDriverWait(driver, Duration.ofSeconds(2))
//                    .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xp)));
//            return err.getText();
//        } catch (TimeoutException te) {
//            return null;
//        }
//    }
//
//    private void waitUntilFieldEnabledByLabel(String labelText) {
//        String xpath = String.format(
//                "//label[normalize-space()='%s']/../following-sibling::div//input[not(@type='hidden')]",
//                labelText);
//        wait.until(d -> {
//            WebElement el = d.findElement(By.xpath(xpath));
//            return el.isEnabled() && el.getAttribute("disabled") == null;
//        });
//    }
//
//    @AfterClass
//    public void tearDown() {
//        if (driver != null) 
//        	driver.quit();
//    }
//}
